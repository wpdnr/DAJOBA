package pack.model.enter;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pack.controller.enter.EnterBean;
import pack.controller.enter.ReviewBean;
import pack.model.emp.EmpDto;

@Repository
public class EnterDaoImpl extends SqlSessionDaoSupport implements EnterDaoInter{
	@Autowired
	public EnterDaoImpl(SqlSessionFactory factory) {
		setSqlSessionFactory(factory);
	}
	
	//기업 검색
	@Override
	public ArrayList<EnterDto> getEnterList(EnterBean bean) {
		
		return (ArrayList)getSqlSession().selectList("selectEnterList", bean);
	}
	
	//오늘의 추천 기업
	@Override
	public ArrayList<EnterDto> getEnterToday() {

		return (ArrayList)getSqlSession().selectList("enterToday");
	}
	
	//기업 정보 상세페이지 - 소개
	@Override
	public EnterDto getEnterDetail(String enter_no) {

		return getSqlSession().selectOne("selectEnterDetail", enter_no);
	}
	
	//기업 정보 상세페이지 - 채용 공고
	@Override
	public ArrayList<EmpDto> getEnterApply(String enter_no) {
		return (ArrayList)getSqlSession().selectList("selectEnterApply", enter_no);
	}
	
}
