package pack.model.enter;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pack.controller.enter.ReviewBean;

@Repository
public class ReviewDaoImpl extends SqlSessionDaoSupport implements ReviewDaoInter{
	@Autowired
	public ReviewDaoImpl(SqlSessionFactory factory) {
		setSqlSessionFactory(factory);
	}
	
	@Override
	public ArrayList<ReviewDto> getReviewList(ReviewBean bean) {
		return (ArrayList)getSqlSession().selectList("selectReviewList", bean);
	}
	
	@Override
	public boolean insertReview(ReviewBean bean) {
		int re = getSqlSession().insert("insertReview", bean);
		if(re > 0) {
			return true;
		}else {
			return false;
		}
	}
	
	@Override
	public boolean deleteReview(String review_no) {
		int re = getSqlSession().delete("deleteReview", review_no);
		if(re > 0)
			return true;
		else
			return false;
	}
	
	public ReviewDaoImpl() {
		// TODO Auto-generated constructor stub
	}

}
