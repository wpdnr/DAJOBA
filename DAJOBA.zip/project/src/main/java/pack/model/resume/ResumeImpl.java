package pack.model.resume;

import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import pack.controller.resume.ResumeBean;

@Repository
public class ResumeImpl extends SqlSessionDaoSupport implements ResumeInter {

	public ResumeImpl(SqlSessionFactory factory) {
		setSqlSessionFactory(factory);
	}

	@Override
	public List<ResumeDto> resumelist(String member_id) throws DataAccessException {
		return getSqlSession().selectList("resumelist", member_id);
	}

	@Override
	public boolean insertResume(ResumeBean bean) throws DataAccessException {
		if (getSqlSession().insert("insertresume", bean) > 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	@Override
	public void delResume(String resume_no) throws DataAccessException {
		getSqlSession().delete("delresume", resume_no);
	}
	
	@Override
	public ResumeDto searchResume(String resume_no) throws DataAccessException {
		return getSqlSession().selectOne("searchResume", resume_no);
	}
}
