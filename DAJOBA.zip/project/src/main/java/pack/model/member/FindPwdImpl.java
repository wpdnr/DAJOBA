package pack.model.member;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pack.controller.member.MemberBean;

@Repository
public class FindPwdImpl extends SqlSessionDaoSupport implements FindPwdInter{
	
	@Autowired
	public FindPwdImpl(SqlSessionFactory factory) {
		setSqlSessionFactory(factory);
	}
	
	@Override
	public boolean isExist(MemberBean bean) {
		MemberDto dto = (MemberDto)getSqlSession().selectOne("findMemberInfo", bean);
		if (dto == null)
			return false;
		else
			return true;
	}
	
	@Override
	public boolean changePwd(MemberBean bean) {
		boolean b = false;
		int re = getSqlSession().update("changeMemberPwd", bean);
		if (re > 0) {
			return b = true;
			
		} else {
			return b;
		}
	}
}
