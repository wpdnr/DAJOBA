package pack.controller.emp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pack.model.emp.EmpDto;
import pack.model.emp.EmpInter;
import pack.model.emp.Emp_dtDto;
import pack.model.enter.EnterDto;


@Controller
public class Emp_dtController {
	
	@Autowired
	private EmpInter empInter;

	@RequestMapping("emp_dt")
	@ResponseBody
	public Map<String, Object> emp_dt(@RequestParam("no") String emp_name) {
		System.out.println(emp_name);
		Emp_dtDto data = empInter.searchOne_emtdt(emp_name);
		EmpDto data1 = empInter.searchOne_emp(emp_name);
		EnterDto data2 =empInter.searchOne_enter(emp_name);		
		
		ArrayList<Object> list = new ArrayList<Object>();
		
		list.add(data);
		list.add(data1);
		list.add(data2);
		
		Map<String, Object> Datas = new HashMap<String, Object>();
		Datas.put("datas", list);
		Datas.put("current_page", "emp");
		return Datas;
	}
}
