package pack.controller.resume;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pack.model.resume.ResumeInter;

@Controller
public class ResumeDelController {
	@Autowired
	private ResumeInter inter;
	
	@RequestMapping("delresume")
	public String delResume(@RequestParam("resume_no") String resume_no) {
		
		inter.delResume(resume_no);
		
		return "redirect:/resumelist";
	}
	
}
