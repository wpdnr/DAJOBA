package pack.controller.resume;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import pack.model.resume.ResumeDto;
import pack.model.resume.ResumeInter;

@Controller
public class ResumeListController {
	
	@Autowired
	private ResumeInter reinter;
	
	@RequestMapping("resumelist")
	public ModelAndView resumelist(HttpSession session) {
		String member_id = (String)session.getAttribute("member_id");
		List<ResumeDto> rdto = reinter.resumelist(member_id);
		ModelAndView view = new ModelAndView("resume/resumelist");
		view.addObject("res", rdto);
		return view;
	}
}
