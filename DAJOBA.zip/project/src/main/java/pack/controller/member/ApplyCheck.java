package pack.controller.member;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import pack.model.member.ApplyCheckDto;
import pack.model.member.MemberInter;

@Controller
public class ApplyCheck {
	@Autowired
	private MemberInter inter;
	@RequestMapping("applycheck")
	public ModelAndView ApplyCheck(HttpSession session) {
		String member_id = (String)session.getAttribute("member_id");
		ModelAndView view = new ModelAndView("mypage/applycheck");
		
		List<ApplyCheckDto> check = inter.applycheck(member_id);
		view.addObject("app",check);
		
		return view;
	}
}
