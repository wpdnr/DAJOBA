function insRow() {
	
			i++;
			count1++;

			oTbl = document.getElementById("addTable");
			var oRow = oTbl.insertRow();
			oRow.onmouseover = function() {
				oTbl.clickedRowIndex = this.rowIndex
			};

			var oCell = oRow.insertCell();
			var frmTag = "<input type='text' id = 'addexp' name='addexp' size='50'>";
			frmTag += "<input type=button value='삭제' onclick='removeRow()' style='cursor:hand'>";
			frmTag += "<input type='hidden' name='count1' value='"+count1+"'>";
			oCell.innerHTML = frmTag;
		}
		
		function insRow1() {
			j++;
			count2++;

			oTbl1 = document.getElementById("addcert");
			var oRow2 = oTbl1.insertRow();
			oRow2.onmouseover = function() {
				oTbl1.clickedRowIndex = this.rowIndex
			};

			var oCell2 = oRow2.insertCell();
			var frmTag2 = "<input type='text' id = 'addcert' name='addcert' size='50'>";
			frmTag2 += "<input type=button value='삭제' onclick='removeRow2()' style='cursor:hand'>";
			frmTag2 += "<input type='hidden' name='count2' value='"+count2+"'>";
			oCell2.innerHTML = frmTag2;
		}
		
		function insRow2() {
			a++;
			count3++;

			oTbl2 = document.getElementById("addetc");
			var oRow3 = oTbl2.insertRow();
			oRow3.onmouseover = function() {
				oTbl2.clickedRowIndex = this.rowIndex
			};

			var oCell3 = oRow3.insertCell();
			var frmTag3 = "<input type='text' id = 'etc' name='etc' size='50'>";
			frmTag3 += "<input type=button value='삭제' onclick='removeRow3()' style='cursor:hand'>";
			frmTag3 += "<input type='hidden' name='count3' value='"+count3+"'>";
			oCell3.innerHTML = frmTag3;
		}


		function removeRow() {
			oTbl.deleteRow(oTbl.clickedRowIndex);
			--count1;
		}
		function removeRow2() {
			oTbl1.deleteRow(oTbl1.clickedRowIndex);
			--count2;
		}
		
		function removeRow3() {
			oTbl2.deleteRow(oTbl2.clickedRowIndex);
			--count3;
		}
	
		function benefitcheck(){
			alert(count1);
			alert(count2);
			alert(count3);
			var check = true;
			var check2 = true;
			var check3 = true;
			for(var i=0;i<count1;i++){
			//alert($("input[name=addexp]:eq(" + i + ")").val());
			if($("input[name=addexp]:eq(" + i + ")").val() == ""
				|| $("input[name=addexp]:eq(" + i + ")").val() == null){
				alert(i+1 + "번째 경력사항 값 입력");
				frm.addexp.focus();
				check = false;
				break;
			 }
		
			}
			
			if(check==true){
				for(var j=0;j<count2;j++){
				//alert($("input[name=addcert]:eq(" + j + ")").val());
				if($("input[name=addcert]:eq(" + j + ")").val() == ""
					|| $("input[name=addcert]:eq(" + j + ")").val() == null){
					alert(j+1 +"번째 자격증 값 입력");
					frm.addcert.focus();
					check2 = false;
					break;
				  }
				 }
				}
			if(check1==true){
			for(var k=0;k<count3;k++){
			//alert($("input[name=etc]:eq(" + k + ")").val());
			if($("input[name=etc]:eq(" + k + ")").val() == ""
				|| $("input[name=etc]:eq(" + k + ")").val() == null){
				alert(k+1 +"번쩨 기타 사항 값 입력");
				frm.etc.focus();
				check3 = false;
				break;
					 }
				}
			}
			
			if(check == true || check2== true || check3 == true){
				frm.submit();
			}
			else{
				return false;
			}
		}
		
		function back(){
			location.href="resumelist";
		}
		
		function re(){
			location.href="resumeinsert";
		}
		
		