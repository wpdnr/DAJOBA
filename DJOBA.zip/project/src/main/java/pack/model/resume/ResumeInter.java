package pack.model.resume;

import java.util.List;

import org.springframework.dao.DataAccessException;

import pack.controller.resume.ResumeBean;

public interface ResumeInter {
	List<ResumeDto> resumelist(String member_id) throws DataAccessException;
	
	boolean insertResume(ResumeBean bean) throws DataAccessException;
	
	void delResume(String resume_no) throws DataAccessException;
	
	ResumeDto searchResume(String resume_no) throws DataAccessException;
}
