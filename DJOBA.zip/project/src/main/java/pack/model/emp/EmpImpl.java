package pack.model.emp;

import java.util.List;


import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import pack.controller.emp.EmpAppBean;
import pack.model.enter.EnterDto;

@Repository
public class EmpImpl extends SqlSessionDaoSupport implements EmpInter {

	@Autowired
	public EmpImpl(SqlSessionFactory factory) {
		setSqlSessionFactory(factory);
	}

	@Override
	public List<EmpDto> empAll() throws DataAccessException {
		return getSqlSession().selectList("empAll");
	}

	@Override
	public List<EmpDto> searchEmp(String enter_name) throws DataAccessException {
		return getSqlSession().selectList("searchem", enter_name);
	}

	@Override
	public List<EnterDto> enterAll() throws DataAccessException {
		return getSqlSession().selectList("enterAll");
	}

	@Override
	public List<EnterDto> searchEnter(String enter_name) throws DataAccessException {
		return getSqlSession().selectList("searchenter", enter_name);
	}

	@Override
	public List<Emp_dtDto> searchEmp_dt(String enter_name) throws DataAccessException {

		return getSqlSession().selectList("searchEmp_dt", enter_name);
	}

	@Override
	public Emp_dtDto searchOne_emtdt(String emp_name) throws DataAccessException {

		return getSqlSession().selectOne("searchOne_empdt", emp_name);
	}

	@Override
	public EnterDto searchOne_enter(String emp_name) throws DataAccessException {

		return getSqlSession().selectOne("searchOne_enter", emp_name);
	}

	@Override
	public EmpDto searchOne_emp(String emp_name) throws DataAccessException {

		return getSqlSession().selectOne("searchOne_emp", emp_name);
	}

	@Override
	public void count(String emp_name) throws DataAccessException {
		getSqlSession().update("count", emp_name);

	}

	@Override
	public List<ApplyDto> searchList(String member_id) throws DataAccessException {
		
		return getSqlSession().selectList("applyResume",member_id );
	}

	@Override
	public boolean applysuccess(EmpAppBean bean) throws DataAccessException {
		if(getSqlSession().insert("apply",bean) > 0) {
			return true;
		}else {
			return false;
		}
	}
}
