package pack.model.emp;

import java.util.List;


import org.springframework.dao.DataAccessException;

import pack.controller.emp.EmpAppBean;
import pack.model.enter.EnterDto;

public interface EmpInter {
	   List<EmpDto> empAll() throws DataAccessException;

	   List<EmpDto> searchEmp(String enter_name) throws DataAccessException;
	   
	   List<EnterDto> enterAll() throws DataAccessException;
	   
	   List<EnterDto> searchEnter(String enter_name) throws DataAccessException;
	   
	   List<Emp_dtDto> searchEmp_dt(String enter_name) throws DataAccessException;

	   Emp_dtDto searchOne_emtdt(String emp_name) throws DataAccessException;
	   
	   EnterDto searchOne_enter(String emp_name) throws DataAccessException;
	   
	   EmpDto searchOne_emp(String emp_name) throws DataAccessException;
	   
	   void count(String emp_name) throws DataAccessException;
	   
	  List<ApplyDto> searchList(String member_id) throws DataAccessException;
	   
	  boolean applysuccess(EmpAppBean bean) throws DataAccessException;
	   
	   
	}