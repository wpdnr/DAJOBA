package pack.model.member;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import pack.controller.member.MemberBean;


public interface MemberInter {
	
	ArrayList<ZipcodeDto> zipcodeRead(String area3);
	
	boolean checkId(String member_id);//요고
	int checkEmail(String member_email);//요거 추가
	int checkPhone(String member_phone);//요거 추가
	
	boolean checkPwd(MemberBean bean);
	
	boolean loginCheck(MemberBean bean);
	
	MemberDto getMember(String member_id);
	
	boolean memberInsert(MemberBean bean);	//요고
	boolean memberUpdate(MemberBean bean);
	boolean memberDelete(MemberBean bean);
	
	String maxNum();
	
	List<ApplyCheckDto> applycheck(String member_id);
}
