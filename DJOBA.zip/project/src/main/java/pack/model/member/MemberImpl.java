package pack.model.member;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pack.controller.member.MemberBean;


@Repository
public class MemberImpl extends SqlSessionDaoSupport implements MemberInter {

	@Autowired //DB연결
	public MemberImpl(SqlSessionFactory factory) {
		setSqlSessionFactory(factory);
	}

	@Override //주소 검색
	public ArrayList<ZipcodeDto> zipcodeRead(String area3) {
		return (ArrayList) getSqlSession().selectList("selectZiplist", area3);
	}

	@Override  //아이디 중복
	public boolean checkId(String member_id) {
		String id = (String)getSqlSession().selectOne("checkid", member_id);
		if (id == null)
			return true;
		else
			return false;
	}
	
	@Override //(추가) 이메일 중복 검사
	public int checkEmail(String member_email) {
		return getSqlSession().selectOne("checkemail", member_email);
	}
	
	@Override //(추가) 번호 중복 검사
	public int checkPhone(String member_phone) {
		return getSqlSession().selectOne("checkphone", member_phone);
	}

	@Override
	public boolean checkPwd(MemberBean bean) {
		String pwd = (String)getSqlSession().selectOne("checkpwd", bean);
		if (pwd == null)
			return false;
		else
			return true;
	}
	
	@Override //회원가입
	public boolean memberInsert(MemberBean bean) {
		boolean b = false;
		
		MemberDto dto = (MemberDto)getSqlSession().selectOne("checkAll", bean);
		
		if(dto == null) {
			bean.setMember_birth(bean.getBirth_yy() + "-" + bean.getBirth_mm() + "-" + bean.getBirth_dd());
			bean.setMember_email(bean.getMember_email1() + "@" + bean.getMember_email2());
			bean.setMember_date();
			int re = getSqlSession().insert("insertMember", bean);
			if (re > 0) {
				return b = true;
				
			} else {
				return b;
			}
		}
		return b;
	}

	@Override //로그인 
	public boolean loginCheck(MemberBean bean) {
		MemberDto dto = getSqlSession().selectOne("loginCheck", bean);
		if (dto != null) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public MemberDto getMember(String member_id) {
		return (MemberDto)getSqlSession().selectOne("getMember", member_id);
	}

	@Override
	public boolean memberUpdate(MemberBean bean) {
		int re = getSqlSession().update("memberUpdate", bean);
		if (re > 0) {
			return true;

		} else {
			return false;
		}
	}

	@Override
	public String maxNum() {
		if(getSqlSession().selectOne("maxNum") == null) return "0";
		return getSqlSession().selectOne("maxNum");
	}
	
	
	@Override
	public boolean memberDelete(MemberBean bean) {
		String id = (String)getSqlSession().selectOne("checkid", bean.getMember_id());
		if (id != null) {
			int re = getSqlSession().delete("memberDelete", bean);			
			if (re > 0) {
				return true;
			} else {
				return false;
			}
		}else {
			return false;
		}
	}
	
	@Override
	public List<ApplyCheckDto> applycheck(String member_id) {
		
		return getSqlSession().selectList("applycheck", member_id);
	}
	
	
}
