package pack.model.enter;

import java.util.ArrayList;

import pack.controller.enter.ReviewBean;

public interface ReviewDaoInter {
	ArrayList<ReviewDto> getReviewList(ReviewBean bean);
	
	
	boolean insertReview(ReviewBean bean);
	boolean deleteReview(String review_no);
}
