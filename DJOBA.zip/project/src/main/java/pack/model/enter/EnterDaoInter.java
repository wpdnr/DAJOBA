package pack.model.enter;

import java.util.ArrayList;

import pack.controller.enter.EnterBean;
import pack.model.emp.EmpDto;

public interface EnterDaoInter {
	
	ArrayList<EnterDto> getEnterList(EnterBean bean);
	
	
	ArrayList<EnterDto> getEnterToday();
	EnterDto getEnterDetail(String enter_no);
	ArrayList<EmpDto> getEnterApply(String enter_no);
}
