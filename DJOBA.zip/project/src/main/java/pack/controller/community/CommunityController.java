package pack.controller.community;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import pack.model.community.CommunityDto;
import pack.model.community.CommunityInter;


@Controller
public class CommunityController {
	@Autowired
	private CommunityInter inter;
		
	private int tot;
	private int plist = 10;
	private int pageSu;
	
	public ArrayList<CommunityDto> getList(ArrayList<CommunityDto> list, int page){
		ArrayList<CommunityDto> result = new ArrayList<CommunityDto>();
		int start = (page - 1) * plist;
		int size = plist <= list.size() - start?plist:list.size() - start;
		
		for (int i = 0; i < size; i++) {
			result.add(i, list.get(start + i));
		}
		return result;
	}
	 public int getPageSu() {  //총 페이지 수
	      pageSu = tot / plist;
	      if(tot % plist > 0) pageSu += 1;
	      return pageSu;
	   }

	
	 @RequestMapping("community")
	   public ModelAndView process(@RequestParam("page")int page) {
	     // tot = inter.totalCnt();   //전체 레코드수
	      //아직 에러~!
	      //String p_id = (String) session.getAttribute("p_id");
	      ArrayList<CommunityDto> list = inter.getList();
	      //System.out.println(p_id);
	      //ArrayList<TpDto> list = tpinter.getMyList(p_id);
	      ArrayList<CommunityDto> result = new ArrayList<CommunityDto>();
	      result = getList(list, page);
	      
	      //model.addAttribute("p_id", p_id);
	      
	      ModelAndView model = new ModelAndView("community/community");
	      
	      model.addObject("data", result);
	      model.addObject("pageSu", getPageSu());
	      model.addObject("page", page);
	      model.addObject("current_page", "community");
	      
	      
	      return model;
	   }
}
