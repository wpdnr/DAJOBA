package pack.controller.community;

import java.util.Calendar;

public class CommunityBean {
	private int community_no, community_readcnt, community_gnum, community_onum, community_nested;
	private String member_num,community_name,  community_pass, community_title, community_cont, community_cip, community_cdate;
	private String searchName, searchValue;

	public String getCommunity_pass() {	
		return community_pass;
	}
	public void setCommunity_pass(String community_pass) {
		this.community_pass = community_pass;
	}
	public int getCommunity_no() {
		return community_no;
	}
	public void setCommunity_no(int community_no) {
		this.community_no = community_no;
	}
	public int getCommunity_readcnt() {
		return community_readcnt;
	}
	public void setCommunity_readcnt(int community_readcnt) {
		this.community_readcnt = community_readcnt;
	}
	public int getCommunity_gnum() {
		return community_gnum;
	}
	public void setCommunity_gnum(int community_gnum) {
		this.community_gnum = community_gnum;
	}
	public int getCommunity_onum() {
		return community_onum;
	}
	public void setCommunity_onum(int community_onum) {
		this.community_onum = community_onum;
	}
	public int getCommunity_nested() {
		return community_nested;
	}
	public void setCommunity_nested(int community_nested) {
		this.community_nested = community_nested;
	}
	public String getMember_num() {
		return member_num;
	}
	public void setMember_num(String member_num) {
		this.member_num = member_num;
	}
	public String getCommunity_name() {
		return community_name;
	}
	public void setCommunity_name(String community_name) {
		this.community_name = community_name;
	}
	public String getCommunity_title() {
		return community_title;
	}
	public void setCommunity_title(String community_title) {
		this.community_title = community_title;
	}
	public String getCommunity_cont() {
		return community_cont;
	}
	public void setCommunity_cont(String community_cont) {
		this.community_cont = community_cont;
	}
	public String getCommunity_cip() {
		return community_cip;
	}
	public void setCommunity_cip(String community_cip) {
		this.community_cip = community_cip;
	}
	public String getCommunity_cdate() {
		return community_cdate;
	}
	public void setCommunity_cdate(String community_cdate) {
		this.community_cdate = community_cdate;
	}
	
	public void setCommunity_cdate() {
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		this.community_cdate = year + "-" + month + "-" + day;
	}
	public String getSearchName() {
		return searchName;
	}
	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}
	public String getSearchValue() {
		return searchValue;
	}
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}
	
}
