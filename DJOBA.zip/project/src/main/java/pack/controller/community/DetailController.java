package pack.controller.community;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import pack.model.community.CommunityInter;


@Controller
public class DetailController {
	@Autowired
	private CommunityInter inter;
	
	@RequestMapping("detail")
	public ModelAndView detail(
			@RequestParam("community_no") String community_no,
			@RequestParam("page") String page){
		inter.updateReadcnt(community_no);
		
		ModelAndView model = new ModelAndView("community/detail");
		model.addObject("data", inter.getDetail(community_no));
		model.addObject("page", page);
		model.addObject("current_page", "community");
		
		return model;
	}
}