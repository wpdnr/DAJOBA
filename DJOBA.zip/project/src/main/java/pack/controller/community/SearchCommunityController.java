package pack.controller.community;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import pack.model.community.CommunityDto;
import pack.model.community.CommunityInter;


@Controller
public class SearchCommunityController {
	@Autowired
	private CommunityInter inter;
	
	@RequestMapping("search")
	public ModelAndView search(CommunityBean bean) {
		ArrayList<CommunityDto> list = inter.getSearch(bean);
		
		ModelAndView view = new ModelAndView("community/community","data",list);
		view.addObject("page", "1");
		view.addObject("current_page", "community");
		return view;
	}
}
