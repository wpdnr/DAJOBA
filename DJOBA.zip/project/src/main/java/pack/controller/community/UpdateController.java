package pack.controller.community;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import pack.model.community.CommunityInter;


@Controller
public class UpdateController {
	@Autowired
	private CommunityInter inter;
	
	@RequestMapping(value="update",method=RequestMethod.GET)
	public ModelAndView abc(
			@RequestParam("community_no") String community_no,
			@RequestParam("page") String page){
				ModelAndView view = new ModelAndView("community/update", "data", inter.getDetail(community_no));
			view.addObject("page", page);
			return view;
			}
	
	@RequestMapping(value="update",method=RequestMethod.POST)
	public ModelAndView def(
			@RequestParam("community_no") String community_no,
			@RequestParam("page") String page,
			//@RequestParam("community_cont") String community_cont,
			CommunityBean bean){
	//	bean = inter.selectForm(community_no);
	//	bean.setCommunity_cont(community_cont);
		
		//비밀번호 체크
		
		String community_pass = inter.selectPass(community_no);
		ModelAndView view = new ModelAndView();
		if(bean.getCommunity_pass().equals(community_pass)) { 
			inter.update(bean);
			view.setViewName("community/detail");
		}else {
			view.setViewName("community/update");
			view.addObject("msg", "비밀번호 불일치");
		}
		view.addObject("data", bean);
		view.addObject("page", page);
		
		return view;
	}
			
}
