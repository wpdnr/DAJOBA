package pack.controller.community;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import pack.model.community.CommunityInter;


@Controller
public class InsertController {
	@Autowired
	private CommunityInter inter;
	
	@RequestMapping(value="insert",method=RequestMethod.GET)
	public String abc(){
		return "community/insform";
	}
	
	@RequestMapping(value="insert",method=RequestMethod.POST)
	public ModelAndView def(CommunityBean bean) {
//		bean.setCommunity_cont(bean.getCommunity_cont().replaceAll("(\r\n\|\r|\n|\n\r)")," ");
		bean.setCommunity_cdate();
		
		int newNum = inter.currentNum() + 1;
		String a="1";//여기에 세션 넣기
		;
		bean.setMember_num(a);
		bean.setCommunity_no(newNum);
		bean.setCommunity_gnum(newNum);
		
		ModelAndView model = new ModelAndView();
		if(inter.insert(bean)) {
			model.setViewName("redirect:/community?page=1");
			return model;
		}
		else {
			model.setViewName("community/error");
			return model;
		}
			
		
	}
}
