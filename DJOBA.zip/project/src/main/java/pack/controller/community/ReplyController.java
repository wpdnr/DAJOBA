package pack.controller.community;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import pack.model.community.CommunityInter;


@Controller
public class ReplyController {
	@Autowired
	private CommunityInter inter;
	
	@RequestMapping(value="reply",method=RequestMethod.GET)
	public ModelAndView abc(
			@RequestParam("community_no") String community_no,
			@RequestParam("page") String page){
		ModelAndView view = new ModelAndView("community/reply", "data", inter.getDetail(community_no));
		view.addObject("page", page);
		return view;
	}
	
	@RequestMapping(value="reply",method=RequestMethod.POST)
	public String def(
			@RequestParam("page") String page, 
			CommunityBean bean){
		//onum 갱신
		bean.setCommunity_onum(bean.getCommunity_onum() + 1);
		
		inter.updateOnum(bean);
		
		bean.setCommunity_cdate();
		bean.setCommunity_no(inter.currentNum() + 1);  //새글 번호
		bean.setCommunity_nested(bean.getCommunity_nested() + 1); //들여쓰기
		
		if(inter.insertReply(bean))
			return "redirect:/community?page=" + page;
		else
			return "community/error";
	}
}
