package pack.controller.emp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import pack.model.emp.EmpDto;
import pack.model.emp.EmpInter;
import pack.model.emp.Emp_dtDto;
import pack.model.enter.EnterDto;



@Controller
public class SearchEmpController {
   @Autowired
   private EmpInter empInter; 
   
   @RequestMapping("empsearch")
   public ModelAndView search(@RequestParam("enter_name") String enter_name) {
      
      ModelAndView view = new ModelAndView();
      List<EmpDto> list_e = empInter.searchEmp(enter_name);
      System.out.println(list_e);
      List<EnterDto> list_et = empInter.searchEnter(enter_name);
      List<Emp_dtDto> list_dt = empInter.searchEmp_dt(enter_name);
      view.addObject("emp",list_e);
      view.addObject("enter",list_et);
      view.addObject("emp_dt", list_dt);
      view.setViewName("emp/emp_search");
      view.addObject("current_page", "emp");
      
      return view;
   }
}