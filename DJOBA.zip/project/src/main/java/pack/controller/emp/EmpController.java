package pack.controller.emp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import pack.model.emp.EmpDto;
import pack.model.emp.EmpInter;
import pack.model.enter.EnterDto;


@Controller
public class EmpController {
	@Autowired
	private EmpInter empInter;

	
	@RequestMapping("emp")
	public ModelAndView loginMain() {
		List<EmpDto> em = empInter.empAll();
		List<EnterDto> enter = empInter.enterAll();
		
	    ModelAndView view = new ModelAndView();  
	    
	    view.addObject("enter",enter);
	    view.addObject("emp",em);
	    view.setViewName("emp/emp");
		view.addObject("current_page", "emp");

		return view;
	   }
}
