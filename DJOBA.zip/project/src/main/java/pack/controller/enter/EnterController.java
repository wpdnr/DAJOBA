package pack.controller.enter;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import pack.model.emp.EmpDto;
import pack.model.enter.EnterDaoInter;
import pack.model.enter.EnterDto;

@Controller
public class EnterController {
	
	@Autowired
	private EnterDaoInter inter;
	
	@RequestMapping("enter")	//상단 메뉴바 '기업' 클릭 시 
	public ModelAndView enterMain() {
		ArrayList<EnterDto> list = inter.getEnterToday();
		ModelAndView model = new ModelAndView("enter/enter_main");
		model.addObject("todaylist", list);
		model.addObject("current_page", "enter");
				
		return model;
	}
	
	@RequestMapping(value = "enter_search", method = RequestMethod.POST)	//[enter_main] 직접 검색 시
	public ModelAndView enterNameSearch(EnterBean bean) {
		bean.setSearchCategory("enter_name");
		ArrayList<EnterDto> list = inter.getEnterList(bean);//searchCategory, searchValue
		ModelAndView view = new ModelAndView("enter/enter_search", "enterlist", list);
		view.addObject("current_page", "enter");
		return view;
	}
	
	@RequestMapping(value = "enter_search", method = RequestMethod.GET)	//[enter_main] 산업군 검색 시
	public ModelAndView enterCategorySearch(EnterBean bean) {
		bean.setSearchCategory("enter_industry");
		ArrayList<EnterDto> list = inter.getEnterList(bean);
		ModelAndView view = new ModelAndView("enter/enter_search", "enterlist", list);
		view.addObject("current_page", "enter");
		return view;
	}
	
	@RequestMapping({"enter_detail","enter_describe"})
	public ModelAndView enterDetailDiscribe(@RequestParam("enter_no") String enter_no) {
		
		EnterDto dto = new EnterDto();
		dto = inter.getEnterDetail(enter_no);
		
		ModelAndView model = new ModelAndView("enter/detail_describe");
		model.addObject("dto", dto);
		model.addObject("current_page", "enter");
		
		return model;
	}
	
	@RequestMapping("enter_emp")
	public ModelAndView enterDetailApply(@RequestParam("enter_no") String enter_no) {
		
		ArrayList<EmpDto> list = new ArrayList<EmpDto>();
		EnterDto dto = new EnterDto();
		list = inter.getEnterApply(enter_no);
		
		ModelAndView model = new ModelAndView("enter/detail_emp","list", list);
		dto = inter.getEnterDetail(enter_no);
		model.addObject("dto", dto);
		model.addObject("current_page", "enter");
		return model;
	}
	
}
