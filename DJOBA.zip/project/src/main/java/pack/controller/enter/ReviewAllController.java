package pack.controller.enter;

import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import pack.model.enter.EnterDaoInter;
import pack.model.enter.EnterDto;
import pack.model.enter.ReviewDaoInter;
import pack.model.enter.ReviewDto;

@Controller
public class ReviewAllController {
	@Autowired
	private ReviewDaoInter inter;
	
	@Autowired
	private EnterDaoInter e_inter;
	//종사자
	@RequestMapping(value="enter_interview",method=RequestMethod.GET)
	public ModelAndView enterInterview(ReviewBean bean, @RequestParam("enter_no") String enter_no) {
		// System.out.println(bean.getEnter_no() + " " + bean.getReview_category());
		EnterDto dto = new EnterDto();
		dto = e_inter.getEnterDetail(enter_no);

		ArrayList<ReviewDto> list = new ArrayList<ReviewDto>();
		
		list = inter.getReviewList(bean);
		ModelAndView model = new ModelAndView("enter/enter_interview");
		model.addObject("dto", dto);
		model.addObject("list", list);
		return model;
	}
	//면접 후기
	@RequestMapping("enter_review")
	public ModelAndView enterReview(ReviewBean bean, @RequestParam("enter_no") String enter_no) {
		// System.out.println(bean.getEnter_no() + " " + bean.getReview_category());
		EnterDto dto = new EnterDto();
		dto = e_inter.getEnterDetail(enter_no);
		ArrayList<ReviewDto> list = new ArrayList<ReviewDto>();
		list = inter.getReviewList(bean);
		ModelAndView model = new ModelAndView("enter/enter_review");
		model.addObject("dto", dto);
		model.addObject("list", list);
		return model;
	}
	//합격자 팁
	@RequestMapping("enter_success")
	public ModelAndView enterSuccess(ReviewBean bean, @RequestParam("enter_no") String enter_no) {
		// System.out.println(bean.getEnter_no() + " " + bean.getReview_category());
		EnterDto dto = new EnterDto();
		dto = e_inter.getEnterDetail(enter_no);
		ArrayList<ReviewDto> list = new ArrayList<ReviewDto>();
		list = inter.getReviewList(bean);
		ModelAndView model = new ModelAndView("enter/enter_success");
		model.addObject("dto", dto);
		model.addObject("list", list);
		return model;
	}
	//리뷰 달기 종사자, 면접후기, 합격자소서
	@RequestMapping(value = "reviewinsform", method = RequestMethod.POST)
	public ModelAndView enterReviewInsert(HttpServletRequest request, ReviewBean bean,
			@RequestParam("enter_no") String enter_no) {
		bean.setReview_ip(request.getRemoteAddr());
		bean.setReview_date();
		bean.setReview_like("0");
		bean.setEnter_no(enter_no);
		if(bean.getReview_rate() == "" || bean.getReview_rate() == null) {
			bean.setReview_rate("0");
		}
		inter.insertReview(bean);
		EnterDto dto = new EnterDto();
		dto = e_inter.getEnterDetail(enter_no);
		ArrayList<ReviewDto> list = new ArrayList<ReviewDto>();
		list = inter.getReviewList(bean);
		ModelAndView model = new ModelAndView();
		model.addObject("dto", dto);
		model.addObject("list", list);
		model.setViewName("enter/enter_" + bean.getReview_category());
		return model;
	}
	
	//종사자, 면접후기, 합격자소서 삭제
	@RequestMapping(value = "reviewdelete", method = RequestMethod.GET)
	public ModelAndView enterReviewDelete(ReviewBean bean) {
		boolean b = inter.deleteReview(bean.getReview_no());
		EnterDto dto = new EnterDto();
		dto = e_inter.getEnterDetail(bean.getEnter_no());
		if (b) {
			ModelAndView model = new ModelAndView();
			ArrayList<ReviewDto> list = new ArrayList<ReviewDto>();
			list = inter.getReviewList(bean);
			model.addObject("dto", dto);
			model.addObject("list", list);
			model.setViewName("enter/enter_"+bean.getReview_category());
			return model;
		} else {
			ModelAndView view = new ModelAndView("message");
			view.addObject("url", "main1");
			view.addObject("msg", "리뷰 삭제 실패!! 어째서 일까요?");
			view.addObject("dto", dto);
			return view;
		}

	}
}
